/*

Copyright (c) 2020 Becky Kring.  All rights and permissions are retained without
warranty or guarantee. Author: Brian Alan Sroufek.  This header allows downloaders
and purchasers to modify this software, so long as they include this header.

This header includes version 1.0 and later.

*/

Please refer to the README.txt file in the ../src directory for descriptions of
each module in this library.

