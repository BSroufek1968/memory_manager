/*

Copyright (c) 2020 Becky Kring.  All rights and permissions are retained without
warranty or guarantee. Author: Brian Alan Sroufek.  This header allows downloaders
and purchasers to modify this software, so long as they include this header.

This header includes version 1.0 and later.

*/


#ifdef BASIC_LIB_DEFS_H
#else
#define BASIC_LIB_DEFS_H

#ifndef WINDOWS
#define WINDOWS
#endif

#ifndef WINDOWS
#include <unistd.h>
#else
#endif



#ifdef __cplusplus
extern "C" {
#endif




                                                                    
/*
 Basic Library Definitions and Macros
*/
                                                                    

#define	TRUE		(0 == 0)
#define FALSE		(0 == 1)

#define MIN(a,b)	((a) <= (b) ? a : b)
#define MAX(a,b)	((a) >= (b) ? a : b)

#define SMIN(a,b)	((a) < (b) ? a : b)
#define SMAX(a,b)	((a) > (b) ? a : b)

	/* USES_VIRT_MEM, when TRUE, only makes calls to malloc, free, realloc
	   instead of managing memory
	*/
#define USES_VIRT_MEM	FALSE
#define ZERO_NEW_MEM	TRUE
#define DO_THREAD_SLEEP	FALSE



#define MAX_TABLE_LINE	16384


#ifdef __cplusplus
}	/* cpp */
#endif

#endif


