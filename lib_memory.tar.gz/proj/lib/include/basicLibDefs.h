/*

Copyright (c) 2020 tsam-software.org/Brian's Software.  All rights and permissions
are retained by Brian's Software.  Author: Brian Alan Sroufek.  This header
allows downloaders and purchasers to modify this software, so long as they include
this header.

This header includes version 1.0 and later.

*/


#ifndef BASIC_LIB_DEFS_H
#define BASIC_LIB_DEFS_H






                                                                    
/*
 Basic Library Definitions and Macros
*/
                                                                    

#define	TRUE		(0 == 0)
#define FALSE		(0 == 1)

#define MIN(a,b)	((a) <= (b) ? a : b)
#define MAX(a,b)	((a) >= (b) ? a : b)

#define SMIN(a,b)	((a) < (b) ? a : b)
#define SMAX(a,b)	((a) > (b) ? a : b)

	/* USES_VIRT_MEM, when TRUE, only makes calls to malloc, free, realloc
	   instead of managing memory
	*/
#define USES_VIRT_MEM	FALSE
#define ZERO_NEW_MEM	TRUE
#define DO_THREAD_SLEEP	FALSE




#endif


