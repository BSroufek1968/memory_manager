/*

Copyright (c) 2020 Becky Kring.  All rights and permissions are retained without
warranty or guarantee. Author: Brian Alan Sroufek.  This header allows downloaders
and purchasers to modify this software, so long as they include this header.

This header includes version 1.0 and later.

*/


#ifdef MMEM_H
#else
#define MMEM_H


#ifdef __cplusplus
extern "C" {
#endif

                                                                 
	/* Main Entry Points */
	                                                         

void *	Mmalloc(int blockSize);
void 	Mfree(void *memBlock);
void * 	Mrealloc(void *memBlock, int newBlockSize);

	                                                         
	/*  Memory Functions */
	                                                         

int	MMEMInitLib();
void 	MMEMDestroyLib();
long 	MMEMGetLibSize();
long 	MMEMGetLibDataSize();

int 	MMEMGetMaxLibSize();
int 	MMEMSetMaxLibSize(long newMaxSize);



#ifdef __cplusplus
}	/* cpp */
#endif


#endif
