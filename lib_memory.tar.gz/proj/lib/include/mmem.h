/*

Copyright (c) 2020 tsam-software.org/Brian's Software.  All rights and permissions
are retained by Brian's Software.  Author: Brian Alan Sroufek.  This header
allows downloaders and purchasers to modify this software, so long as they include
this header.

This header includes version 1.0 and later.

*/


#ifndef MMEM_H
#define MMEM_H


                                                                 
	/* Main Entry Points */
	                                                         

void *	Mmalloc(int blockSize);
void 	Mfree(void *memBlock);
void * 	Mrealloc(int newBlockSize, void *memBlock);

	                                                         
	/*  Memory Functions */
	                                                         

int	MMEMInitLib();
void 	MMEMDestroyLib();
long 	MMEMGetLibSize();
long 	MMEMGetLibDataSize();

int 	MMEMGetMaxLibSize();
int 	MMEMSetMaxLibSize(long newMaxSize);



#endif
