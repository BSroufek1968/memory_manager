/*

Copyright (c) 2020 Becky Kring.  All rights and permissions are retained without
warranty or guarantee. Author: Brian Alan Sroufek.  This header allows downloaders
and purchasers to modify this software, so long as they include this header.

This header includes version 1.0 and later.

*/

lib.ini			A .INI file used by the library test program to provide
			configurable entry/value pairs to any library or program for
			ease of configuration without recompilation of the program
			files.  MINIgetEntry() is an easy function for the usual
			retrievable of entry values for given group/entry pairs.

mtxtflags.txt, 		These files are provided by the test module
mtxtvars.txt,		for featured, dynamic textual templating for many purposes.
mtxttemplates.txt	Note that flags and variables must be loaded or set program-
			matically prior to text template instanciation.

			The flags, variables and templates are loadable and settable
			by library functions prior to any call to
			MTXTinstanciateTemplate().  In my opinion, this is how
			dynamic SQL should be done in any medium to large SQL/
			database project.

			A template written to a text file, such as
			"mtxttemplates.txt" is identified in this format:

			TemplateGroupName TemplateName TemplateNumber Outputfile

			This identifies the template uniquely and it is followed
			by template pieces, each of which may be headed by a
			boolean expression causing its following text piece to
			be included in this instanciated template.  Variables
			may be included in the text pieces by brackets, such as
			the following.

			TemplateGroupName TemplateName TemplateNumber Outputfile
			{
			  select [Vone], [Vtwo]
			}
			Fone : Ftwo ; (Fthree : Ffour)	<-- BOOLEAN EXPRESSION
			{				    WHICH CAUSES ITS
			  from table1, [Vthree]	    	    TEXT TO BE INCLUDED
							    WHEN TRUE
			}

			The boolean expression uses flags loaded and perhaps set
			in code (MTXTsetFlag).  The colon is logical AND and the
			semicolon is logical OR while the exclamation point is
			logical NOT.  The text piece within braces may contain
			variables, like "Vone" or "Vtwo", which may also be set
			in code (MTXTsetVariable).  Upon instanciation
			(MTXTinstanciateTemplate), these flags and variables are
			dynamically evaluated and the final text is returned.
			
mexpr.txt,		These files are provided to test and show how expressions
mtest_expr.txt		are and can be handled by the mexpr.c module.

