/*

Copyright (c) 2020 tsam-software.org/Brian's Software.  All rights and permissions
are retained by Brian's Software.  Author: Brian Alan Sroufek.  This header
allows downloaders and purchasers to modify this software, so long as they include
this header.

This header includes version 1.0 and later.

*/


#include <basicLibDefs.h>
#include <stdlib.h>
#include <stdio.h>
#include <mmem.h>


/* Memory FreeTree Structures */
                                                                 
#ifdef MDEBUG
#define MDEBUG
#endif

#ifdef MDEBUG
#endif


                                                                 

static
char * version = "1.0";


/*
 Memory Management Structures 
*/


typedef
struct {
	/* don't change the order of these */
  void *memBlock;
  int blockSize;

}  MMEMFreeTreeNodeT;


	/* this structure immediately preceeds a freed node in the memory chunk */
typedef
struct MMEMFreeTree {
	struct
	MMEMFreeTree 	*left,
			*right,
			*parent;

	MMEMFreeTreeNodeT node;
} MMEMFreeTreeT;
                                                                 


typedef
struct {
	int blockSize;
} MMEMBlockHdrT;


typedef
struct MMEMChunkType {
	int chunkSize;

	int chunkFilled;
	int chunkDataUsed;
	int chunkMemFreed;

		/* actual virt memory chunk */
	void *MMEMChunk;

	int MMEMnumFreeTreeNodes;

		/* reuse of freed memory */
	MMEMFreeTreeT *MMEMTree;

	struct MMEMChunkType 	*prev,
				*next;
} MMEMChunkT;


typedef
struct {
	long 	libSize,
		libData;

	int 	MMEMnumChunks;

	MMEMChunkT *chunksOfMem,
		   *lastChunk,
                   *currentChunk;
} MMEMT;

	                                                         
/*
                                                                 
  Main Memory Management Code and Entry Points
                                                                 
*/
	
int 	MMEMInitialized 	= 0,
	MMEMDefaultChunkSize 	= 16384;

long 	MMEMmaxLibSize 		= -1L;


/*
	                                                         
	  main data structure
	                                                         
*/

MMEMT		MMEM;


/*
                                                         
-------------------------------------------------------
                                                         
*/


MMEMChunkT * 	MMEMgetNewChunk(int memChunkSize);
int		MMEMfreeChunk(MMEMChunkT *chunk);

int 	MMEMinitChunk(int memChunkSize, void *memChunk);
int  	MMEMInitFreeTreeNode(MMEMFreeTreeT *ptr);

int	MMEMinsertChunk(MMEMChunkT *memChunk);
int	MMEMremoveChunk(MMEMChunkT *memChunk);
			/* finds existing chunk for memory block */
MMEMChunkT 	*MMEMfindChunkForBlock(void *memBlock);

/*
	                                                         
	  Utility functions
	                                                         
*/

/*
		handles virtual memory from system
*/
void 	*MMEMgetVirt(int blockSize);
int 	MMEMfreeVirt(void *chunkPtr);

void 	MMEMinitBlock(int memBlockSize, void *memBlock, char fillChr);
void *	MMEMaddBlock(int memBlockSize);
int 	MMEMfreeBlock(void *memBlock); 
void 	*MMEMreallocBlock(int newBlockSize, void *memBlock);

int	alignMemBlock(int blockSize);
void	zeroMemBlock(int blockSize, void *memBlock);

		/* returns memBlock when able to append memBlock to chunk */
void *	MMEMappendBlock(int memBlockSize, MMEMChunkT *chunk);
		/* returns memBlock when able to insert memBlock into chunk */
void *	MMEMinsertBlock(int memBlockSize, MMEMChunkT *chunk);
		/* returns memBlock when able to find block in chunk */
void *	MMEMgetFreeBlock(int memBlockSize);

/*
                                                                 
  FreeTree Management
                                                                 
*/

/*
	important function: finds a reusable memory block
*/
MMEMFreeTreeT *MMEMfindFreeTreeNode(MMEMChunkT *chunk, int blockSize);

/*
	removes from memory chunk
*/
int MMEMaddFreeNode(MMEMChunkT *chunk, MMEMFreeTreeT *freeTreePtr);
/*
	adds to memory chunk
*/
int MMEMremoveFreeNode(MMEMChunkT *chunk, MMEMFreeTreeT *ptr);


/*
                                                         
                                                         
  Implementations
                                                         
                                                         
*/

/*
	                                                         
	  Memory Functions
	                                                         
*/

int	alignMemBlock(int blockSize)
{
  int word,
      wholeBlockSize;

  if (blockSize < 1)
  {
#ifdef MDEBUG
fprintf(stderr, "alignMemBlock returning min size = %d.\n",sizeof(void*));
#endif
    return sizeof(void*);
  }

  wholeBlockSize = blockSize;

  if ((word = (sizeof(void*) - (blockSize % sizeof(void*)))) < sizeof(void*))
    wholeBlockSize += word;

#ifdef MDEBUG
fprintf(stderr, "alignMemBlock returning wholeBlockSize = %d.\n", wholeBlockSize);
#endif
  return wholeBlockSize;
}


void 	MMEMinitBlock(int memBlockSize, void *memBlock, char fillChr)
{
#ifdef MDEBUG
fprintf(stderr, "MMEMinitBlock: memBlockSize = %d\n", memBlockSize);
#endif
  if ((memBlockSize > 0) && memBlock)
  {
    register
    int index;

    register
    char *ptr;

    for (index = 0, ptr = (char *)memBlock;

         index++ < memBlockSize;

         *ptr = fillChr,
         ++ptr
        );
  }
#ifdef MDEBUG
fprintf(stderr, "MMEMinitBlock: returning\n");
#endif
}


void	zeroMemBlock(int blockSize, void *memBlock)
{
  MMEMinitBlock(blockSize, memBlock, (char)NULL);
}

/*
	first tries to append memBlock, then tries to insert but fails in chunk if neither happens
	then tries to get more memory and appends to it if possible
	otherwise general failure to get memory
*/
void *	MMEMaddBlock(int memBlockSize)
{
	MMEMChunkT *chunkPtr;
	void *memBlock;

/*
		try current Chunk
*/
	if (!(chunkPtr = MMEM.currentChunk))
	{
#ifdef MDEBUG
	fprintf(stderr, "MmemaddBlock failed on currentChunk\n");
#endif
	  return (void *)NULL;
	}

#ifdef MDEBUG
	fprintf(stderr, "MmemaddBlock calling MMEMgetFreeBlock...\n");
#endif
	if (memBlock = MMEMgetFreeBlock(memBlockSize))
 	{
#ifdef MDEBUG
	fprintf(stderr, "MmemaddBlock returning from MMEMgetFreeBlock...\n");
#endif
	  return memBlock;
	}

#ifdef MDEBUG
	fprintf(stderr, "MmemaddBlock calling MMEMappendBlock(%d, %ld)...\n", memBlockSize, chunkPtr);
#endif
	if (memBlock = MMEMappendBlock(memBlockSize, chunkPtr))
	{
#ifdef MDEBUG
	fprintf(stderr, "MmemaddBlock returning from MMEMappendBlock...\n");
#endif
	  return memBlock;
	}

		/* try getting new chunk */

#ifdef MDEBUG
	fprintf(stderr, "MmemaddBlock getting new chunk(%d, %d)...\n", memBlockSize, MMEMDefaultChunkSize);
#endif

	if (memBlockSize > MMEMDefaultChunkSize)
	  chunkPtr = MMEMgetNewChunk(memBlockSize);
	else
	  chunkPtr = MMEMgetNewChunk(MMEMDefaultChunkSize);

		/* if no more virtual memory, then return NULL */
	if (!chunkPtr)
	{
#ifdef MDEBUG
	fprintf(stderr, "MmemaddBlock failed in MMEMgetNewChunk...\n");
#endif
	  return (void *)NULL;
	}
	
	else {
	  if (MMEMinsertChunk(chunkPtr))
	  {
#ifdef MDEBUG
	fprintf(stderr, "MmemaddBlock: successfully called insertChunk(%ld) ...\n",chunkPtr);
#endif
	  }

	  else {
#ifdef MDEBUG
	fprintf(stderr, "MmemaddBlock: failed in call to insertChunk(%ld) ...\n",chunkPtr);
#endif
	  }
	}

		/* must be able to append to new chunk */
#ifdef MDEBUG
	fprintf(stderr, "MmemaddBlock calling MMEMappendBlock...\n");
#endif
	if (memBlock = MMEMappendBlock(memBlockSize, chunkPtr))
	{
#ifdef MDEBUG
	fprintf(stderr, "MmemaddBlock returning after MMEMappendBlock...\n");
#endif
	    MMEM.currentChunk = chunkPtr;
	    return memBlock;
	}
	
		/* failure to get memory block */
#ifdef MDEBUG
	fprintf(stderr, "MmemaddBlock failed in MMEMappendBlock...\n");
#endif
	MMEM.currentChunk = (MMEMChunkT *)NULL;

	return (void *)NULL;
}


int MMEMfreeBlock(void *memBlock)
{
	MMEMChunkT *chunkPtr;

  	int hdrSize,
	    blockSize,
	    wholeMemBlock;

#ifdef MDEBUG
	fprintf(stderr, "MMEMfreeBlock entered with %ld...\n",memBlock);
#endif

 	if (!memBlock)
    	{
#ifdef MDEBUG
	fprintf(stderr, "MMEMfreeBlock entered with NULL memBlock...\n");
#endif
	  return FALSE;
	}

	if (!(chunkPtr = MMEMfindChunkForBlock(memBlock)))
	{
#ifdef MDEBUG
	fprintf(stderr, "MMEMfreeBlock failed in MMEMfindChunkForBlock %ld.\n", memBlock);
#endif
	  return FALSE;
	}

#ifdef MDEBUG
	fprintf(stderr, "MMEMfreeBlock succeeded in MMEMfindChunkForBlock %ld.\n", memBlock);
#endif

	blockSize = ((MMEMBlockHdrT*)(memBlock - alignMemBlock(sizeof(MMEMBlockHdrT))))->blockSize;
	wholeMemBlock = alignMemBlock(blockSize) + alignMemBlock(sizeof(MMEMBlockHdrT));

#ifdef MDEBUG
	fprintf(stderr, "MMEMfreeBlock memBlock %ld, wholeMemBlock size = %d, blockSize = %d\n",memBlock, blockSize + alignMemBlock(sizeof(MMEMBlockHdrT)), blockSize);
#endif

/* ------------------------------------------------------------------------- */
	/* check if last mem node in chunk */
	if ((memBlock + blockSize) == chunkPtr->chunkSize)
	{
	  chunkPtr->chunkFilled 	-= wholeMemBlock;
	  chunkPtr->chunkDataUsed 	-= blockSize;

	  MMEM.libSize 			-= wholeMemBlock;
	  MMEM.libData 			-= blockSize;

	    /* appended */
#ifdef MDEBUG
	fprintf(stderr, "MMEMfreeBlock returning TRUE1\n");
#endif
	  return TRUE;
	}

	/* otherwise try to append a free tree node */
	else {
	  int 			found 	 = FALSE;
	  void *		newNode  = MMEMappendBlock(sizeof(MMEMFreeTreeT), chunkPtr);
	  MMEMFreeTreeT *	freeBlockPtr = (MMEMFreeTreeT*)NULL;

/* ------------------------------------------------------------------------- */
	  if (newNode)
	  {
	    freeBlockPtr 			= (MMEMFreeTreeT *)newNode;

    	    freeBlockPtr->node.blockSize 	= blockSize;
	    freeBlockPtr->node.memBlock  	= memBlock;
  
	    freeBlockPtr->parent 		= 
	    freeBlockPtr->left 			= 
	    freeBlockPtr->right 		= (MMEMFreeTreeT*)NULL;

	    chunkPtr->chunkMemFreed		+= wholeMemBlock;
  
		/* checking free tree for nodes */
	    if (chunkPtr->MMEMTree)
	    {
	      register
	      MMEMFreeTreeT *treePtr = chunkPtr->MMEMTree;

#ifdef MDEBUG
	  fprintf(stderr, "MMEMfreeBlock entering free TREE with newNode = %ld\n",newNode);
#endif
  
	      do {
		  if (blockSize <= treePtr->node.blockSize)
		  {
#ifdef MDEBUG
	  fprintf(stderr, "MMEMfreeBlock chunk %ld, tree %ld, blockSize %d node size %d\n",
			chunkPtr, treePtr,blockSize, treePtr->node.blockSize);
#endif
		    if (treePtr->left)
		    {
#ifdef MDEBUG
	  fprintf(stderr, "MMEMfreeBlock going left...\n");
#endif
		      treePtr = treePtr->left;
		    }
		    else {
#ifdef MDEBUG
	  fprintf(stderr, "MMEMfreeBlock found node...\n");
#endif
		      found = TRUE;
		    }
 		  }
		  else if (treePtr->right)
		  {
#ifdef MDEBUG
	  fprintf(stderr, "MMEMfreeBlock going right...\n");
#endif
		    treePtr = treePtr->right;
		  }
  
		  else
		    found = TRUE;
 	      } while (!found);
  
#ifdef MDEBUG
	  fprintf(stderr, "MMEMfreeBlock found leaf node in freeTree \n");
#endif
  
		  /* get new node for this freed memBlock */
	      freeBlockPtr->parent = treePtr;
  
		    /* insert on left */
	      if (blockSize <= treePtr->node.blockSize)
	      {
	        treePtr->left = freeBlockPtr;
	      }
 
	        /* insert on right */
	      else {
	        treePtr->right = freeBlockPtr;
	      }

	      chunkPtr->MMEMnumFreeTreeNodes++;
	    }

	      /* set empty tree to newnode */
	    else {
#ifdef MDEBUG
	    fprintf(stderr, "MMEMfreeBlock setting empty free tree to node %ld, blockSize %d, memBlock %ld.\n",
			freeBlockPtr, freeBlockPtr->node.blockSize, memBlock);
#endif
	      chunkPtr->MMEMTree 	= freeBlockPtr;

	      chunkPtr->MMEMnumFreeTreeNodes = 1;
	    }

#ifdef MDEBUG
	    fprintf(stderr, "MMEMfreeBlock set free tree to node %ld, blockSize %d, memBlock %ld.\n",
			freeBlockPtr, freeBlockPtr->node.blockSize, memBlock);
#endif

	    chunkPtr->chunkMemFreed	+= wholeMemBlock;
	    chunkPtr->chunkDataUsed 	-= blockSize;

	    MMEM.libSize 		-= wholeMemBlock;
	    MMEM.libData 		-= blockSize;

#ifdef MDEBUG
	    fprintf(stderr, "MMEMfreeBlock returning TRUE after stats(#%d)\n",chunkPtr->MMEMnumFreeTreeNodes);
#endif
	    return TRUE;
	  }
/* ------------------------------------------------------------------------- */
	  
	  else {
#ifdef MDEBUG
	    fprintf(stderr, "MMEMfreeBlock failed in MMEMappendBlock.\n");
#endif

	    	/* update stats */
	    chunkPtr->chunkDataUsed -= blockSize;

	    MMEM.libSize 		-= wholeMemBlock;
	    MMEM.libData 		-= blockSize;

	    return FALSE;
	  }

	  return FALSE;
	}
}


int MMEMInitLib()
{
  MMEMChunkT *newChunk;

  if (MMEMInitialized || (MMEMmaxLibSize == 0L))
    return TRUE;
  
  MMEM.libSize = MMEM.libData = 0L;

  MMEM.MMEMnumChunks = 0;

  MMEM.chunksOfMem 	= 
  MMEM.lastChunk 	= 
  MMEM.currentChunk 	= NULL;
  
#ifdef MDEBUG
fprintf(stderr, "MMEMInitLib: calling MMEMgetNewChunk\n");
#endif

  newChunk = MMEMgetNewChunk(MMEMDefaultChunkSize);

  if (newChunk)
  {
#ifdef MDEBUG
fprintf(stderr, "MMEMInitLib: MMEMgetNewChunk succeeded,%ld\n",newChunk);
#endif
  }
#ifdef MDEBUG
  else 
fprintf(stderr, "MMEMInitLib: calling MMEMinsertChunk when newChunk = %ld\n", newChunk);
#endif

  if (newChunk && MMEMinsertChunk(newChunk))
    MMEMInitialized 	= TRUE;
#ifdef MDEBUG
  else 
    fprintf(stderr, "MMEMInitLib: MMEMinsertChunk failed.\n", newChunk);
#endif

#ifdef MDEBUG
  fprintf(stderr, "MMEMInitLib: done with return of %d\n", MMEMInitialized);
#endif

  return MMEMInitialized;
}


void   MMEMDestroyLib()
{
  if (!MMEMInitialized)
    return;

  for (;

       MMEM.MMEMnumChunks;

       MMEMremoveChunk(MMEM.chunksOfMem)
      );
  
  MMEMInitialized = FALSE;
}


long   MMEMGetLibSize()
{
  return MMEM.libSize;
}


long   MMEMGetLibDataSize()
{
  return MMEM.libData;
}


int   MMEMGetMaxLibSize()
{
  return MMEMmaxLibSize;
}


int   MMEMSetMaxLibSize(long newMaxSize)
{
  MMEMmaxLibSize = newMaxSize;
}


void 	*MMEMgetVirt(int blockSize)
{
  int alignedBlockSize = alignMemBlock(blockSize);
  void *memChunk;

#ifdef MDEBUG
    fprintf(stderr, "MMEMgetVirt entered with alignedBlocksize = %d.\n", alignedBlockSize);
#endif

  if ((MMEMmaxLibSize < 0L)
      ||
      ((MMEM.libSize + alignedBlockSize) < MMEMmaxLibSize)
     )
    memChunk = malloc(alignedBlockSize);
  else {
#ifdef MDEBUG
    fprintf(stderr, "MMEMgetVirt failed after malloc.\n");
#endif
    memChunk = (void *)NULL;
  }

  return memChunk;
}


int 	MMEMfreeVirt(void *chunkPtr)
{
  if (!chunkPtr)
  {
#ifdef MDEBUG
    fprintf(stderr, "MMEMfreeVirt failed on arguments.\n");
#endif
	return FALSE;
  }

#ifdef MDEBUG
    fprintf(stderr, "MMEMfreeVirt calling free.\n");
#endif

  free(chunkPtr);

  return TRUE;
}


MMEMChunkT *
MMEMgetNewChunk(int memChunkSize)
{
  int alignedHdrSize,
      alignedChunkSize,
      alignedBlockSize;
  void *virtMem;
  MMEMChunkT *newChunk;

#ifdef MDEBUG
  fprintf(stderr, "MMEMgetNewChunk: calling alignMemBlock(memChunkSize(%d))\n", memChunkSize);
#endif

  alignedHdrSize   = alignMemBlock(sizeof(MMEMBlockHdrT));
  alignedChunkSize = alignMemBlock(sizeof(MMEMChunkT));
  alignedBlockSize = alignMemBlock(memChunkSize);

#ifdef MDEBUG
  fprintf(stderr, "MMEMgetNewChunk: memChunkSize(%d,aligned = %d), alignedBlockSize = %d\n",
	 memChunkSize, alignedChunkSize, alignedBlockSize);
#endif

  if ((alignedHdrSize + alignedChunkSize) >= alignedBlockSize)
  {
#ifdef MDEBUG
  fprintf(stderr, "MMEMgetNewChunk: alignedBlockSize is too small for chunk structure.\n");
#endif
    return (MMEMChunkT *)NULL;
  }
/*
    defaults to standard memory allocation,
    but raw virtual memory is better and preferred
*/
  if ((MMEMmaxLibSize < 0L)
      ||
      ((MMEM.libSize + alignedBlockSize) < MMEMmaxLibSize)
     )
  {
#ifdef MDEBUG
fprintf(stderr, "MMEMgetNewChunk: calling MMEMgetVirt...\n");
#endif
    if (!(virtMem = (MMEMChunkT *)MMEMgetVirt(alignedBlockSize)))
    {
#ifdef MDEBUG
fprintf(stderr, "MMEMgetNewChunk: failed on MMEMgetVirt(%d)...\n", alignedBlockSize);
#endif
      return FALSE;
    }
    
	/* set chunk size in its header */
    ((MMEMBlockHdrT*)virtMem)->blockSize = alignedChunkSize;

	/* set chunk start */
    newChunk = (MMEMChunkT*)(virtMem + alignedHdrSize);
    newChunk->MMEMChunk = virtMem;
    newChunk->chunkFilled = alignedHdrSize + alignedChunkSize;

#if 0
    zeroMemBlock(alignedBlockSize - newChunk->chunkFilled, newChunk + newChunk->chunkFilled);
#endif

#ifdef MDEBUG
fprintf(stderr, "MMEMgetNewChunk: MMEMinitChunk...\n");
#endif
    if (!MMEMinitChunk(alignedBlockSize, newChunk))
    {
#ifdef MDEBUG
fprintf(stderr, "MMEMgetNewChunk: returning failed initChunk...\n");
#endif
      if (newChunk->MMEMChunk)
        MMEMfreeVirt(newChunk->MMEMChunk);
    }

	/* successful acquisition and initialization of new memory chunk */
    else {
/*
	MMEM.MMEMnumChunks++;

	MMEM.libSize += alignedChunkSize;
*/
    }
  }
  else {
#ifdef MDEBUG
fprintf(stderr, "MMEMgetNewChunk setting newChunk to NULL\n");
#endif
    newChunk = (void *)NULL;
  }
#ifdef MDEBUG
fprintf(stderr, "MMEMgetNewChunk: MMEMinitChunk done\n");
#endif

  return (MMEMChunkT *)newChunk;
}


int
MMEMfreeChunk(MMEMChunkT *chunk)
{
  if (!chunk)
    return FALSE;

  if (chunk->MMEMChunk)
    MMEMfreeVirt(chunk->MMEMChunk);

  return TRUE;
}


int   MMEMinitChunk(int memChunkSize, void *memChunk)
{
  register
  MMEMChunkT *chunk = (MMEMChunkT*)memChunk;

  if (memChunkSize < 1 || !memChunk)
  {
#ifdef MDEBUG
    fprintf(stderr, "MMEMinitChunk failed on arguments.\n");
#endif
    return FALSE;
  }

  chunk->chunkSize =
  memChunkSize     = alignMemBlock(memChunkSize);

/* set in getNewChunk
  chunk->chunkFilled  =
*/
  chunk->chunkMemFreed  = 0;

  chunk->MMEMnumFreeTreeNodes = 0;

  chunk->MMEMTree = (MMEMFreeTreeT *)NULL;
  
  chunk->next = chunk->prev = (MMEMChunkT *)NULL;  
  
#ifdef MDEBUG
    fprintf(stderr, "MMEMinitChunk returning.\n");
#endif

  return TRUE;
}


int  MMEMInitFreeTreeNode(MMEMFreeTreeT *ptr)
{
  if (!ptr)
    return FALSE;

  ptr->left =
  ptr->right =
  ptr->parent = (MMEMFreeTreeT *)NULL;

  ptr->node.blockSize = 0;
  ptr->node.memBlock = (void*)NULL;

  return TRUE;
}


int  MMEMinsertChunk(MMEMChunkT *memChunk)
{
  register
  MMEMChunkT *chunkList;
  MMEMChunkT *foundChunk;

  if (!memChunk || !memChunk->MMEMChunk)
  {
#ifdef MDEBUG
    fprintf(stderr, "MMEMinsertChunk: failed on arguments...\n");
#endif
    return FALSE;
  }

	/* check if already at maximum library size */
  if ((MMEMmaxLibSize > -1L) && ((memChunk->chunkSize + MMEM.libSize) > MMEMmaxLibSize))
  {
#ifdef MDEBUG
    fprintf(stderr, "MMEMinsertChunk: failed on max lib size %d...\n",MMEMmaxLibSize);
#endif
    return FALSE;
  }
	
    /* check if this is the first chunk to be added */
  if (!MMEM.chunksOfMem)
  {
#ifdef MDEBUG
    fprintf(stderr, "MMEMinsertChunk: setting chunkOfMem...\n");
#endif
	MMEM.chunksOfMem = MMEM.lastChunk = MMEM.currentChunk = memChunk;

	MMEM.MMEMnumChunks++;
  	MMEM.libSize += (long)memChunk->chunkSize;
  }

  else {
#ifdef MDEBUG
    fprintf(stderr, "MMEMinsertChunk: going through chunkList...\n");
#endif
    for (foundChunk = (MMEMChunkT*)NULL,
	 chunkList = MMEM.chunksOfMem;
  
         chunkList;
    
         chunkList = chunkList->next
        )
    {
        /* insert chunk in order of ascending memory address */
      if (memChunk->MMEMChunk < chunkList->MMEMChunk)
      {
#ifdef MDEBUG
    fprintf(stderr, "MMEMinsertChunk: foundChunk1 %ld...\n",chunkList->MMEMChunk);
#endif
      	foundChunk = chunkList;
      }

      else if (memChunk->MMEMChunk == chunkList->MMEMChunk)
      {
#ifdef MDEBUG
    fprintf(stderr, "MMEMinsertChunk: MMEMChunk %ld == chunk list node %ld...\n",
	memChunk->MMEMChunk,chunkList->MMEMChunk);
#endif
	MMEM.currentChunk = memChunk;
	return memChunk;
      }

      else {
#ifdef MDEBUG
    fprintf(stderr, "MMEMinsertChunk: stopping loop on chunk List = %ld...\n",chunkList->MMEMChunk);
#endif
	break;
      }
    } /* for */

    if (foundChunk)
    {
	/* prepend new chunk to list */
      if (foundChunk == MMEM.chunksOfMem)
      {
#ifdef MDEBUG
    fprintf(stderr, "MMEMinsertChunk: prepend foundChunk %ld to MMEM.chunksOfMem %ld...\n",foundChunk,MMEM.chunksOfMem);
#endif
	memChunk->next = MMEM.chunksOfMem;
        MMEM.chunksOfMem = memChunk;
      }

	/* insert in middle before foundChunk */
      else {
#ifdef MDEBUG
    fprintf(stderr, "MMEMinsertChunk: insert memChunk %ld to foundChunk %ld ...\n",memChunk,foundChunk);
#endif
	memChunk->next = foundChunk;
   	memChunk->prev = foundChunk->prev;
      }
    }

	/* append to end */
    else {
#ifdef MDEBUG
    fprintf(stderr, "MMEMinsertChunk: append memChunk %ld to lastChunk %ld ...\n",memChunk,MMEM.lastChunk);
#endif
	memChunk->prev = MMEM.lastChunk;
        MMEM.lastChunk->next = memChunk;
        MMEM.lastChunk = memChunk;
    }

          /* inserted, so get out after stats */
#ifdef MDEBUG
    fprintf(stderr, "MMEMinsertChunk: returning from insert1...\n");
#endif
  }

  ++MMEM.MMEMnumChunks;
  MMEM.libSize += (long)memChunk->chunkSize;

  MMEM.currentChunk = memChunk;

#ifdef MDEBUG
    fprintf(stderr, "MMEMinsertChunk: returning now(%ld)...\n",memChunk);
#endif

  return TRUE;
}


int  MMEMremoveChunk(MMEMChunkT *memChunk)
{
  if (!memChunk)
    return FALSE;

	/* check if already empty */
  if ((MMEMmaxLibSize < 1L) || !MMEM.chunksOfMem)
    return FALSE;
	
#ifdef MDEBUG
  fprintf(stderr, "MMEMremoveChunk entered.\n");
#endif
	/* check if first node */
  if (memChunk == MMEM.chunksOfMem) {
	/* check if only one node */
    if (MMEM.MMEMnumChunks == 1)
    {
      MMEMdestroyFreeTree(MMEM.chunksOfMem);

      MMEMfreeVirt(MMEM.chunksOfMem->MMEMChunk);

      MMEM.chunksOfMem	=
      MMEM.lastChunk	=
      MMEM.currentChunk	= (MMEMChunkT *)NULL;

      MMEM.libSize	=
      MMEM.libData	= 0L;
    }

	/* deleting first node */
    else { 
      memChunk->next->prev = (MMEMChunkT *)NULL;

      MMEM.libSize	-= (long)memChunk->chunkSize;
      MMEM.libData	-= (long)memChunk->chunkDataUsed;

      MMEMdestroyFreeTree(MMEM.chunksOfMem);

      MMEM.chunksOfMem = memChunk->next;

      MMEMfreeVirt(memChunk->MMEMChunk);
    }
  }

	/* check if last node */
  else if (memChunk == MMEM.lastChunk)
  {
     memChunk->prev->next = (MMEMChunkT *)NULL;
     MMEM.lastChunk = MMEM.lastChunk->prev;

     MMEM.libSize	-= (long)memChunk->chunkSize;
     MMEM.libData	-= (long)memChunk->chunkDataUsed;

     MMEMfreeVirt(memChunk->MMEMChunk);
  }

	/* Middle of list */
  else {
     memChunk->prev->next = memChunk->next;
     memChunk->next->prev = memChunk->prev;

     MMEM.libSize	-= (long)memChunk->chunkSize;
     MMEM.libData	-= (long)memChunk->chunkDataUsed;

     MMEMfreeVirt(memChunk->MMEMChunk);
  }

  --MMEM.MMEMnumChunks;

  return TRUE;
}


/*
      finds existing chunk for memory block
*/
MMEMChunkT   *MMEMfindChunkForBlock(void *memBlock)
{
	register
	MMEMChunkT *chunkList;

	if (!memBlock || !MMEM.MMEMnumChunks)
 	{
#ifdef MDEBUG
	  fprintf(stderr, "MMEMfindChunkForBlock failed on NULL argument %ld,num chunks = %d.\n",
		memBlock,MMEM.MMEMnumChunks);
#endif
	  return (MMEMChunkT *)NULL;
	}

#ifdef MDEBUG
	fprintf(stderr, "MMEMfindChunkForBlock num chunks = %d\n",MMEM.MMEMnumChunks);
#endif

		/* check within current chunk */
	if (MMEM.currentChunk
	    &&
	    (memBlock >= MMEM.currentChunk->MMEMChunk)
	    &&
	    (memBlock <= (MMEM.currentChunk->MMEMChunk + MMEM.currentChunk->chunkSize))
	   )
	{
#ifdef MDEBUG
	  fprintf(stderr, "MMEMfindChunkForBlock returning currentChunk.\n");
#endif
	  return MMEM.currentChunk;
	}
	
	else if (MMEM.lastChunk
	    	 &&
	    	 (memBlock >= MMEM.lastChunk->MMEMChunk)
	     	 &&
	    	 (memBlock <= (MMEM.lastChunk->MMEMChunk + MMEM.lastChunk->chunkSize))
	   )
	{
#ifdef MDEBUG
	  fprintf(stderr, "MMEMfindChunkForBlock returning lastChunk.\n");
#endif
	  return MMEM.lastChunk;
	}

		/* check chunk list */
	else {
	  int index;

#ifdef MDEBUG
	  fprintf(stderr, "MMEMfindChunkForBlock checking chunk list, memBlock (%ld), first(%ld), last(%ld), current(%ld)...\n",
			memBlock, MMEM.chunksOfMem, MMEM.lastChunk, MMEM.currentChunk);
#endif
	  for (index = 0,
	       chunkList = MMEM.lastChunk;

	       chunkList;

	       ++index,
		chunkList = chunkList->prev
	      )
	  {
#ifdef MDEBUG
	  fprintf(stderr, "MMEMfindChunkForBlock #%d, chunkList(%ld), next(%ld)...\n",index,chunkList,chunkList->next);
#endif
	    if (chunkList == MMEM.currentChunk)
	    {
#ifdef MDEBUG
	  fprintf(stderr, "MMEMfindChunkForBlock skipping currentChunk in #%d...\n",index);
#endif
	      continue;
	    }

	    if (chunkList == MMEM.lastChunk)
	    {
#ifdef MDEBUG
	  fprintf(stderr, "MMEMfindChunkForBlock skipping lastChunk in #%d...\n",index);
#endif
	      continue;
	    }

	    if ((memBlock >= chunkList->MMEMChunk)
                &&
 	        (memBlock <= (chunkList->MMEMChunk + chunkList->chunkSize))
	       )
	    {
#ifdef MDEBUG
	  fprintf(stderr, "MMEMfindChunkForBlock found memBlock in chunk #%d...\n",index);
#endif
	      MMEM.currentChunk = chunkList;

	      break;
	    }
	  }

#ifdef MDEBUG
	  if (!chunkList)
	    fprintf(stderr, "MMEMfindChunkForBlock failed in chunkList loop in #%d.\n", index);
	  else
	    fprintf(stderr, "MMEMfindChunkForBlock succeeded in chunkList loop in #%d.\n", index);
#endif

	  return chunkList;
	}
}


int MMEMdestroyFreeTree(MMEMChunkT *chunk)
{
  if (!chunk)
    return FALSE;

  return TRUE;
}


/*
	important function: finds a reusable memory block
*/
MMEMFreeTreeT *MMEMfindFreeTreeNode(MMEMChunkT *chunk, int blockSize)
{
	int found;
	MMEMFreeTreeT *freeTreePtr;

	if (!chunk || (blockSize < 1) || !chunk->MMEMnumFreeTreeNodes)
	{
#ifdef MDEBUG
	  fprintf(stderr, "MMEMfindFreeTreeNode failed on arguments, blockSize = %d, #nodes = %d.\n",
				blockSize, chunk->MMEMnumFreeTreeNodes);
#endif
	  return (MMEMFreeTreeT *)NULL;
	}

#ifdef MDEBUG
	  fprintf(stderr, "MMEMfindFreeTreeNode looking for node, blockSize = %d.\n",blockSize);
#endif
	
	for (found = FALSE,
	     freeTreePtr = chunk->MMEMTree;

	     freeTreePtr && !found;

	    )
	{
#ifdef MDEBUG
	  fprintf(stderr, "MMEMfindFreeTreeNode loop, blockSize = %d, freeTreePtr = %d, freeTreePtr left = %d, freeTreePtr right = %d.\n",
		blockSize,freeTreePtr->node.blockSize,
		(freeTreePtr->left ? freeTreePtr->left->node.blockSize : -1),
		(freeTreePtr->right ? freeTreePtr->right->node.blockSize : -1));
#endif
	  if (blockSize <= freeTreePtr->node.blockSize)
	  {
#ifdef MDEBUG
	    fprintf(stderr, "MMEMfindFreeTreeNode blocksize %d fits in free block %d.\n",
			blockSize, freeTreePtr->node.blockSize);
#endif
	    if (freeTreePtr->left && (blockSize <= freeTreePtr->left->node.blockSize))
	    {
#ifdef MDEBUG
	    fprintf(stderr, "MMEMfindFreeTreeNode going left.\n");
#endif
	      freeTreePtr = freeTreePtr->left;
	    }

	    else {
#ifdef MDEBUG
	    fprintf(stderr, "MMEMfindFreeTreeNode found = TRUE.\n");
#endif
	      found = TRUE;
	    }
	  }
	  else {
#ifdef MDEBUG
	    fprintf(stderr, "MMEMfindFreeTreeNode going right.\n");
#endif
	    freeTreePtr = freeTreePtr->right;
	  }
	}	

#ifdef MDEBUG
	  fprintf(stderr, "MMEMfindFreeTreeNode found = %d for %d.\n",found,blockSize);
#endif

	return freeTreePtr;
}


/*
	removes from memory chunk by adding a freed node from the chunk's free tree
*/
int MMEMaddFreeNode(MMEMChunkT *chunk, MMEMFreeTreeT *freeTreePtr)
{
	int found,
	    blockSize = alignMemBlock(sizeof(MMEMFreeTreeT)),
	    wholeBlockSize = alignMemBlock(sizeof(MMEMBlockHdrT)) + blockSize;
	MMEMFreeTreeT *freeTreeNode,
		      *newNode;

	if (!chunk || !freeTreePtr)
	{
#ifdef MDEBUG
	fprintf(stderr, "MMEMaddFreeNode failed on NULL argument.\n");
#endif
	  return FALSE;
	}

#ifdef MDEBUG
	fprintf(stderr, "MMEMaddFreeNode calling MMEMappendBlock for blockSize %d.\n",blockSize);
#endif

	newNode = MMEMappendBlock(blockSize, chunk);

	if (!newNode)
	{
#ifdef MDEBUG
	  fprintf(stderr, "MMEMaddFreeNode failed in MMEMappendBlock.\n");
#endif
	  return FALSE;
	}

#ifdef MDEBUG
	  fprintf(stderr, "MMEMaddFreeNode copying given node...\n");
#endif

	memmove(newNode, freeTreePtr, blockSize);

	newNode->parent =
	newNode->left	=
    	newNode->right  = (MMEMFreeTreeT *)NULL;

	if (!chunk->MMEMTree)
	{
#ifdef MDEBUG
	  fprintf(stderr, "MMEMaddFreeNode adding to empty tree...\n");
#endif
	  chunk->MMEMTree = newNode;

   	  chunk->chunkMemFreed	+= newNode->node.blockSize;
	  chunk->chunkDataUsed 	-= newNode->node.blockSize;

	  MMEM.libSize 			-= wholeBlockSize;
	  MMEM.libData 			-= blockSize;

	  chunk->MMEMnumFreeTreeNodes = 1;
	}

	 	/* attach leaf node to free tree */
 	else {
#ifdef MDEBUG
	  fprintf(stderr, "MMEMaddFreeNode attaching leaf node to tree...\n");
#endif
	  for (found = FALSE,
	       freeTreeNode = chunk->MMEMTree;
  
	       freeTreeNode && !found;
	      )
          {
	    if (blockSize <= freeTreeNode->node.blockSize)
	      if (freeTreeNode->left)
	        freeTreeNode = freeTreeNode->left;
              else
	        found = TRUE;
   	    else if (freeTreeNode->right)
	      freeTreeNode = freeTreeNode->right;
	    else
	      found = TRUE;
	  }
  
	  newNode->parent = freeTreeNode;

	  if (blockSize <= freeTreeNode->node.blockSize)
	    freeTreeNode->left = newNode;
	  else
	    freeTreeNode->right = newNode;

   	  chunk->chunkMemFreed	+= newNode->node.blockSize;
	  chunk->chunkDataUsed 	-= newNode->node.blockSize;

	  MMEM.libSize 		-= wholeBlockSize;
	  MMEM.libData 		-= blockSize;

	  chunk->MMEMnumFreeTreeNodes++;
	}
	
#ifdef MDEBUG
        fprintf(stderr, "MMEMaddFreeNode returning successfully, #nodes = %d.\n",chunk->MMEMnumFreeTreeNodes);
#endif

  	return TRUE;	
}


/*
	adds to memory chunk by taking a freed node from the chunk's free tree
*/
int MMEMremoveFreeNode(MMEMChunkT *chunk, MMEMFreeTreeT *ptr)
{
	if (!chunk || !ptr)
	  return FALSE;

#ifdef MDEBUG
        fprintf(stderr, "MMEMremoveFreeNode entered.\n");
#endif

  	if (!chunk->MMEMTree)
   	  return FALSE;

		/* see if full subtree */
	if (ptr->left && ptr->right)
	{
		MMEMFreeTreeT *subTree = ptr->right;

		  /* attach left subtree to right's left subtree */
		while (subTree->left)
			subTree = subTree->left;

		subTree->left = ptr->left;
		ptr->left->parent = subTree;

		  /* attach right subtree to ptr's parent */
		if (ptr->parent)
		{
			if (ptr->parent->left == ptr)
				ptr->parent->left = ptr->right;
			else
				ptr->parent->right = ptr->right;

		}
		else
			chunk->MMEMTree = subTree;

		subTree->parent = ptr->parent;
	}

		/* left subtree only */
	else if (ptr->left)
	{
		  /* attach left subtree to ptr's parent */
		if (ptr->parent)
		{
			if (ptr->parent->left == ptr)
				ptr->parent->left = ptr->left;
			else
				ptr->parent->right = ptr->left;

			ptr->left->parent = ptr->parent;
		}
		else {
			chunk->MMEMTree = ptr->left;
			ptr->left->parent = (MMEMFreeTreeT *)NULL;
	 	}
	}

		/* right subtree only */
	else if (ptr->right)
	{
		  /* attach right subtree to ptr's parent */
		if (ptr->parent)
		{
			if (ptr->parent->left == ptr)
				ptr->parent->left = ptr->right;
			else
				ptr->parent->right = ptr->right;

			ptr->right->parent = ptr->parent;

		}
		else {
			chunk->MMEMTree = ptr->right;
			ptr->right->parent = (MMEMFreeTreeT *)NULL;
		}
	}

		/* no subtree */
	else {
		if (!ptr->parent)
			chunk->MMEMTree = (MMEMFreeTreeT *)NULL;
		else if (ptr->parent->left == ptr)
			ptr->parent->left = (MMEMFreeTreeT *)NULL;
		else
			ptr->parent->right = (MMEMFreeTreeT *)NULL;
		
	}

	chunk->chunkDataUsed 	+= ptr->node.blockSize;
	MMEM.libData 		+= ptr->node.blockSize;

	chunk->MMEMnumFreeTreeNodes--;

#ifdef MDEBUG
        fprintf(stderr, "MMEMremoveFreeNode returning`.\n");
#endif

	return TRUE;
}

/*
		returns TRUE when able to append memBlock to chunk
*/
void *	MMEMappendBlock(int memBlockSize, MMEMChunkT *chunk)
{
  	int wholeBlockSize 		= alignMemBlock(memBlockSize) + alignMemBlock(sizeof(MMEMBlockHdrT)),
	    blockSize			= alignMemBlock(memBlockSize);
	void *memBlock;

	if (!chunk || memBlockSize < 1 || !chunk->MMEMChunk)
	{
#ifdef MDEBUG
	fprintf(stderr, "MMEMappendBlock failed in arguments.\n");
#endif
		return (void *)NULL;
	}

#ifdef MDEBUG
	fprintf(stderr, "MMEMappendBlock first calc(%d, %d, %d, %d)...\n",
		memBlockSize, wholeBlockSize, chunk->chunkSize,chunk->chunkFilled);
#endif

	if (wholeBlockSize <= (chunk->chunkSize - chunk->chunkFilled))
	{
	  chunk->chunkDataUsed += (wholeBlockSize - alignMemBlock(sizeof(MMEMBlockHdrT)));

	  memBlock = (void *)(chunk->MMEMChunk + chunk->chunkFilled + alignMemBlock(sizeof(MMEMBlockHdrT)));

 	  ((MMEMBlockHdrT*)(memBlock - alignMemBlock(sizeof(MMEMBlockHdrT))))->blockSize = blockSize;

	  chunk->chunkFilled += wholeBlockSize;

#ifdef MDEBUG
	fprintf(stderr, "MMEMappendBlock returning upon hdr %d, memBlockSize %d, wholeBlockSize %d, chunkFilled %d, data used %d.\n", 
		alignMemBlock(sizeof(MMEMBlockHdrT)), memBlockSize, wholeBlockSize, chunk->chunkFilled, chunk->chunkDataUsed);
#endif

       	  return memBlock; 
	}
	else {
#ifdef MDEBUG
	fprintf(stderr, "MMEMappendBlock failed in wholeBlockSize.\n");
#endif
	  return (void *)NULL;
	}
}


/*
		returns memBlock ptr when found in free tree, may fragment tree node
*/
void *	MMEMinsertBlock(int memBlockSize, MMEMChunkT *chunk)
{
  int wholeBlockSize     = alignMemBlock(sizeof(MMEMBlockHdrT)) + alignMemBlock(memBlockSize);
  MMEMFreeTreeT *treePtr;
  void *memBlock = (void *)NULL;

  if (!chunk || (memBlockSize < 1))
  {
#ifdef MDEBUG
    fprintf(stderr, "MMEMinsertBlock failed on arguments.\n");
#endif
    return (void *)NULL;
  }

  if (!chunk->MMEMTree)
  {
#ifdef MDEBUG
    fprintf(stderr, "MMEMinsertBlock: no free nodes, # num nodes = %d.\n",chunk->MMEMnumFreeTreeNodes);
#endif
    return (void *)NULL;
  }

#ifdef MDEBUG
    fprintf(stderr, "MMEMinsertBlock calling MMEMfindFreeTreeNode...\n");
#endif
  if (treePtr = MMEMfindFreeTreeNode(chunk, wholeBlockSize))
  {
    int blockFragment;

#ifdef MDEBUG
    fprintf(stderr, "MMEMinsertBlock: got free node in MMEMfindFreeTreeNode...\n");
#endif

    memBlock = treePtr->node.memBlock;

      /* check if enough space to chop up this free node */
    blockFragment = alignMemBlock(sizeof(MMEMBlockHdrT)) + treePtr->node.blockSize - wholeBlockSize;

       /* enough to fragment */
    if (blockFragment >= (wholeBlockSize + alignMemBlock(sizeof(MMEMBlockHdrT)) + alignMemBlock(sizeof(void*))))
    {
      MMEMFreeTreeT fragBlock;

#ifdef MDEBUG
    fprintf(stderr, "MMEMinsertBlock: fragmenting wholeBlockSize %d, blockFragment %d...\n",
	wholeBlockSize,blockFragment);
#endif

      if (MMEMremoveFreeNode(chunk, treePtr))
      {
#ifdef MDEBUG
    fprintf(stderr, "MMEMinsertBlock: removed free node...\n");
#endif
		/* now add trailing fragment to memory */
        MMEMInitFreeTreeNode(&fragBlock);

        fragBlock.node.blockSize = blockFragment - alignMemBlock(sizeof(MMEMBlockHdrT));
        fragBlock.node.memBlock = treePtr->node.memBlock + blockFragment;

#ifdef MDEBUG
    fprintf(stderr, "MMEMinsertBlock: calling addFreeNode...\n");
#endif

	if (MMEMaddFreeNode(chunk, &fragBlock))
	{
#ifdef MDEBUG
    fprintf(stderr, "MMEMinsertBlock: added fragmented free node...\n");
#endif
	  return memBlock;
	}

		/* just return original chunk, as free tree had no space for the fragment */
	else {
#ifdef MDEBUG
    fprintf(stderr, "MMEMinsertBlock: addFreeNode failed, returning with wholeBlockSize %d\n",wholeBlockSize);
#endif

	  return memBlock;
	}
      }

      else {
#ifdef MDEBUG
    fprintf(stderr, "MMEMinsertBlock failed in MMEMremoveFreeNode1, returning NULL...\n");
#endif
      	return (void *)NULL;
      }
    }

    else {
#ifdef MDEBUG
    fprintf(stderr, "MMEMinsertBlock did not fragment...\n");
#endif
      if (MMEMremoveFreeNode(chunk, treePtr))
      {
        return memBlock;
      }

      else {
#ifdef MDEBUG
    fprintf(stderr, "MMEMinsertBlock failed in MMEMremoveFreeNode2, returning NULL...\n");
#endif
      	return (void *)NULL;
      }
    }
  }

  else {
#ifdef MDEBUG
    fprintf(stderr, "MMEMinsertBlock returning NULL after findFreeTreeNode failed...\n");
#endif
    return (void *)NULL;
  }
}


void *	MMEMgetFreeBlock(int memBlockSize)
{
  int index,
      wholeBlockSize     = alignMemBlock(sizeof(MMEMBlockHdrT)) + alignMemBlock(memBlockSize);
  MMEMChunkT *chunkList;
  void *memBlock = (void *)NULL;

  if (memBlockSize < 1)
  {
#ifdef MDEBUG
    fprintf(stderr, "MMEMgetFreeBlock failed on arguments.\n");
#endif
    return (void *)NULL;
  }

#ifdef MDEBUG
    fprintf(stderr, "MMEMgetFreeBlock: going through chunkList...\n");
#endif
    for (index = 0,
         chunkList = MMEM.chunksOfMem;
  
         chunkList;
    
	 ++index,
         chunkList = chunkList->next
        )
    {
      if (chunkList->MMEMTree)
      {
#ifdef MDEBUG
    fprintf(stderr, "MMEMgetFreeBlock: checking chunk #%d...\n",index);
#endif

	if (memBlock = MMEMinsertBlock(wholeBlockSize - alignMemBlock(sizeof(MMEMBlockHdrT)), chunkList))
	{
	  MMEM.currentChunk = chunkList;

#ifdef MDEBUG
    fprintf(stderr, "MMEMgetFreeBlock: succeeded finding freeBlock %ld in chunk #%d...\n", memBlock, index);
#endif

    	  zeroMemBlock(wholeBlockSize - alignMemBlock(sizeof(MMEMBlockHdrT)), memBlock);

	  return memBlock;
	}
      }
    }

#ifdef MDEBUG
    fprintf(stderr, "MMEMgetFreeBlock: failed to find freeBlock.\n");
#endif

  return memBlock;
}



/*
                                                                                        
  Main Entry Points
                                                                                        
*/


static
int  threadGate = 0;


void *	Mmalloc(int blockSize)
{
  void *memBlock;

  if (!MMEMInitialized)
    if (!MMEMInitLib())
      return (void *)NULL;

  if (blockSize < 1)
	return (void *)NULL;

#if USES_VIRT_MEM
  return malloc(blockSize);
#endif

  while (++threadGate > 1)
  {
#if DO_THREAD_SLEEP
#endif

    --threadGate;
  }

#ifdef MDEBUG
  fprintf(stderr, "calling MMEMaddBlock in Mmalloc...\n");
#endif
  if (memBlock = MMEMaddBlock(blockSize))
  {
    /* log if necessary */
#ifdef MDEBUG
    fprintf(stderr, "MMEMaddBlock succeeded in Mmalloc...\n");
#endif
  }
#ifdef MDEBUG
  else
    fprintf(stderr, "MMEMaddBlock failed in Mmalloc...\n");
#endif

#ifdef MDEBUG
    fprintf(stderr, "Mmalloc returning on address %ld, blockSize %d, aligned = %d, hdr1 = %d...\n", memBlock, blockSize, alignMemBlock(blockSize),((MMEMBlockHdrT*)(memBlock - alignMemBlock(sizeof(MMEMBlockHdrT))))->blockSize);
#endif

  --threadGate;

  return memBlock;
}


void   	Mfree(void *memBlock)
{
  int found = FALSE;

  if (!MMEMInitialized)
    if (!MMEMInitLib())
      return (void *)NULL;

  if (!memBlock)
    return;

#if USES_VIRT_MEM
  return free(memBlock);
#endif

  while (++threadGate > 1)
  {
#if DO_THREAD_SLEEP
#endif

    --threadGate;
  }

#ifdef MDEBUG
  fprintf(stderr, "Mfree calling MMEMfreeBlock on %ld...\n",memBlock);
#endif

  if (found = MMEMfreeBlock(memBlock))
  {
    /* log if necessary */
#ifdef MDEBUG
  fprintf(stderr, "Mfree found memBlock(%ld) in MMEMfreeBlock.\n",memBlock);
#endif
  }

  --threadGate;

  return;
}


void *  Mrealloc(int newBlockSize, void *memBlock)
{
  register
  int index;
  register
  char *blockPtr,
       *oldBlock;

  int found = FALSE,
      oldBlockSize;
  void *newBlock;
  MMEMBlockHdrT *hdrPtr;
  int endIndex1,
      endIndex2;

  if (!MMEMInitialized)
    if (!MMEMInitLib())
      return (void *)NULL;

#if USES_VIRT_MEM
  return realloc(newBlockSize, memBlock);
#endif

  if (newBlockSize < 1 || !memBlock)
    return (void *)NULL;

#ifdef MDEBUG
  fprintf(stderr, "Mrealloc calling MMEMaddBlock...\n");
#endif

  while (++threadGate > 1)
  {
#if DO_THREAD_SLEEP
#endif

    --threadGate;
  }

  if (newBlock = MMEMaddBlock(newBlockSize))
  {
    /* log if necessary */

      /* copy old to new */
    hdrPtr = (MMEMBlockHdrT*)(memBlock - alignMemBlock(sizeof(MMEMBlockHdrT)));
    oldBlockSize = hdrPtr->blockSize;

    for (blockPtr = (char *)newBlock,
         oldBlock = (char *)memBlock,
         index = 0,
         endIndex1 = MIN(newBlockSize, oldBlockSize);

         index < endIndex1;

         *(blockPtr + index) = *(oldBlock + index),
         ++index
      );

      /* free old block */
#ifdef MDEBUG
  fprintf(stderr, "Mrealloc calling MMEMfreeBlock...\n");
#endif
    if (!MMEMfreeBlock(memBlock))
    {
      /* log if necessary */
#ifdef MDEBUG
  fprintf(stderr, "Mrealloc failed in MMEMfreeBlock...\n");
#endif
    }

    /* zero mem if necessary */
#if ZERO_NEW_MEM

    if (newBlockSize > oldBlockSize)
    {
      for (endIndex2 = newBlockSize,
           index = ++endIndex1;

           index < endIndex2;

           *(blockPtr + index++) = (char)NULL
          );
    }

#endif
  }

  --threadGate;
#ifdef MDEBUG
  fprintf(stderr, "Mrealloc returning...\n");
#endif

  return newBlock;
}


