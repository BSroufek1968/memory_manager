/*

Copyright (c) 2020 tsam-software.org/Brian's Software.  All rights and permissions
are retained by Brian's Software.  Author: Brian Alan Sroufek.  This header
allows downloaders and purchasers to modify this software, so long as they include
this header.

This header includes version 1.0 and later.

*/

The following modules listed here are described per common usage.  Some modules
may be distributed or sold separately from others.

../bin/test_lib.c:	A modifyable module which tests the entire library
			currently available.  Should you download or purchase
			less than the entire library, you can eliminate those
			modules not included in order to test the one(s)
			you have.  Note that all of my library modules use
			mmem for virtual memory management, as described below.

mmem:			This is a memory module which mimics (malloc, free,
			realloc) because I had problems with Windows 2000
			correctly handling memory.  The initialization function
			need not be called, as it is checked prior to each
			of the three functions.  MMEMgetVirt() and MMEMfreeVirt()
			are configurable to your own virtual memory platform, but
			the given versions include only malloc() and free().

mlog:			This module allows for only one log file per application.
			I may extend it later to include more than one log file.
			MLOGinitLib() must be called first.  It is simple to use.

mthread:		This module includes custom mutexes and semaphores for
			possible multiplatform usage.  It has an optional sleep
			function which you may modify by platform, in order to
			more quickly allow switching between threads.

mstructs:		This module includes basic data structures for use in
			general programming.  They employ a naming convention
			in each module in order to program more efficiently
			through grep() and other programs, such as:
			> grep  ML
			for listing all MListT functions.  It's initialization
			function is MInitStructsLib().

mexpr:			This module includes a function for testing regular
			expressions against a given string, called MEXtestRE().
			This function has a test file included as
			../text/mtest_expr.txt.
			It also includes a MEXloadPatterns() function for loading
			parseable patterns from a text file included in the
			../text directory.  The one given is usable for c programs
			and provided as ../text/mexpr.txt.

minifile:		This module loads standard .INI files into searchable
			memory for use by programs, using a primary call of
			MINIgetEntry() to retrieve entry values by given group
			name.

mtemplates:		This featured module provides templating software which
			allows for formatted templates in a text file to be used
			for dynamic instanciation, where loaded flags and loaded
			variables are used for textual expressions and
			substitutions such that no recoding is necessary: just
			the changing of the flags or variables (in text files or
			by functions MTXTsetFlag() and MTXTsetVariable() ) after
			file loading.  This, in my opinion, is the way SQL coding
			should be done, rather than scattering pieces of SQL
			throughout program files after too much logic finding
			them.  This module is generalized for use in any text
			building program.  Note that MTXTloadFlags() and
			MTXTloadVariables() are necessarily called prior to
			MTXTloadTemplates(), as templates rely upon flags and
			variables for their (dynamic) instanciation into text.

Makefile.orig:		This file is provided to show and compile the modules
			based on their dependencies.  Please use and modify
			"Makefile" in the ../src directory for any use of yours
			of these described modules.


